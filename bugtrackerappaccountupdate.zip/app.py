import csv
import io
from datetime import datetime

from flask import Flask, abort, redirect, render_template, request, Response, url_for
from flask_login import (
    LoginManager,
    UserMixin,
    current_user,
    login_required,
    login_user,
    logout_user,
)
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///bugs.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SECRET_KEY"] = "dev-secret-key-change-in-production"
db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

SEVERITIES = ["Low", "Medium", "High", "Critical"]
STATUSES = ["Open", "In Progress", "Resolved", "Closed"]


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    display_name = db.Column(db.String(100), nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Bug(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False, default="")
    severity = db.Column(db.String(20), nullable=False, default="Medium")
    status = db.Column(db.String(20), nullable=False, default="Open")
    reporter_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    assignee_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    reporter = db.relationship("User", foreign_keys=[reporter_id])
    assignee = db.relationship("User", foreign_keys=[assignee_id])


with app.app_context():
    db.create_all()


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    if request.method == "POST":
        user = User.query.filter_by(username=request.form["username"].strip()).first()
        if user and user.check_password(request.form["password"]):
            login_user(user)
            return redirect(url_for("index"))
        return render_template("login.html", error="Invalid username or password")

    return render_template("login.html", error=None)


@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user.is_authenticated:
        return redirect(url_for("index"))

    if request.method == "POST":
        username = request.form["username"].strip()
        if User.query.filter_by(username=username).first():
            return render_template("register.html", error="That username is already taken")

        user = User(username=username, display_name=request.form.get("display_name", "").strip() or username)
        user.set_password(request.form["password"])
        db.session.add(user)
        db.session.commit()
        login_user(user)
        return redirect(url_for("index"))

    return render_template("register.html", error=None)


@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("login"))


@app.route("/account", methods=["GET", "POST"])
@login_required
def account():
    if request.method == "POST":
        if not current_user.check_password(request.form.get("current_password", "")):
            return render_template("account.html", error="Current password is incorrect", success=None)

        display_name = request.form.get("display_name", "").strip()
        if display_name:
            current_user.display_name = display_name

        new_password = request.form.get("new_password", "")
        if new_password:
            if new_password != request.form.get("confirm_password", ""):
                return render_template("account.html", error="New passwords do not match", success=None)
            current_user.set_password(new_password)

        db.session.commit()
        return render_template("account.html", error=None, success="Account details updated")

    return render_template("account.html", error=None, success=None)


@app.route("/")
@login_required
def index():
    status_filter = request.args.get("status", "")
    severity_filter = request.args.get("severity", "")

    query = Bug.query
    if status_filter:
        query = query.filter_by(status=status_filter)
    if severity_filter:
        query = query.filter_by(severity=severity_filter)

    bugs = query.order_by(Bug.created_at.desc()).all()

    counts = {status: Bug.query.filter_by(status=status).count() for status in STATUSES}

    return render_template(
        "index.html",
        bugs=bugs,
        statuses=STATUSES,
        severities=SEVERITIES,
        status_filter=status_filter,
        severity_filter=severity_filter,
        counts=counts,
    )


@app.route("/bugs/new", methods=["GET", "POST"])
@login_required
def new_bug():
    users = User.query.order_by(User.display_name).all()

    if request.method == "POST":
        assignee_id = request.form.get("assignee_id") or None
        bug = Bug(
            title=request.form["title"].strip(),
            description=request.form.get("description", "").strip(),
            severity=request.form.get("severity", "Medium"),
            status=request.form.get("status", "Open"),
            reporter_id=current_user.id,
            assignee_id=assignee_id,
        )
        db.session.add(bug)
        db.session.commit()
        return redirect(url_for("index"))

    return render_template("bug_form.html", bug=None, severities=SEVERITIES, statuses=STATUSES, users=users)


@app.route("/bugs/<int:bug_id>/edit", methods=["GET", "POST"])
@login_required
def edit_bug(bug_id):
    bug = Bug.query.get_or_404(bug_id)
    users = User.query.order_by(User.display_name).all()

    if request.method == "POST":
        bug.title = request.form["title"].strip()
        bug.description = request.form.get("description", "").strip()
        bug.severity = request.form.get("severity", bug.severity)
        bug.status = request.form.get("status", bug.status)
        bug.assignee_id = request.form.get("assignee_id") or None
        db.session.commit()
        return redirect(url_for("index"))

    return render_template("bug_form.html", bug=bug, severities=SEVERITIES, statuses=STATUSES, users=users)


@app.route("/bugs/<int:bug_id>/delete", methods=["POST"])
@login_required
def delete_bug(bug_id):
    bug = Bug.query.get_or_404(bug_id)
    db.session.delete(bug)
    db.session.commit()
    return redirect(url_for("index"))


@app.route("/export/csv")
@login_required
def export_csv():
    bugs = Bug.query.order_by(Bug.created_at.desc()).all()

    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(
        ["ID", "Title", "Description", "Severity", "Status", "Reporter", "Assignee", "Created At", "Updated At"]
    )
    for bug in bugs:
        writer.writerow(
            [
                bug.id,
                bug.title,
                bug.description,
                bug.severity,
                bug.status,
                bug.reporter.display_name,
                bug.assignee.display_name if bug.assignee else "Unassigned",
                bug.created_at.strftime("%Y-%m-%d %H:%M"),
                bug.updated_at.strftime("%Y-%m-%d %H:%M"),
            ]
        )

    filename = f"bug_list_{datetime.utcnow().strftime('%Y%m%d_%H%M')}.csv"
    return Response(
        buffer.getvalue(),
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"},
    )


@app.route("/export/report")
@login_required
def export_report():
    bugs = Bug.query.order_by(Bug.severity.desc(), Bug.created_at.desc()).all()
    return render_template("report.html", bugs=bugs, generated_at=datetime.utcnow())


if __name__ == "__main__":
    app.run(debug=True)
